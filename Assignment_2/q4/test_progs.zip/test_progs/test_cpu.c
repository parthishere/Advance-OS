// test_cpu.c - Test CPU limit
#include <stdio.h>

int main() {
    while(1) {
        // Busy loop to consume CPU
    }
    return 0;
}